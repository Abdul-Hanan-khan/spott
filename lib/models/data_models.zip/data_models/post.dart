// ignore_for_file: invalid_assignment
// ignore_for_file:argument_type_not_assignable
import 'package:spott/models/data_models/place.dart';
import 'package:spott/models/data_models/user.dart';
import 'spot.dart';

enum PostType { text, image, video }

class Post {
  int? _id;
  int? _userId;
  PostType? _type;
  String? _content;
  double? _lat;
  double? _lng;
  String? _address;
  String? _placeId;
  String? _placeType;
  int? _status;
  String? _privacy;
  List<String>? _media;
  int? _views;
  DateTime? _createdAt;
  DateTime? _updatedAt;
  int? _likesCount;
  int? _dislikesCount;
  int? _commentsCount;
  int? _spotsCount;
  int? _totalInteractionsCount;
  User? _user;
  Place? _place;
  bool? _isLiked;
  bool? _isDisliked;
  Spot? _spot;
  bool? _isSeen;
  int? _userCommentCount;

  int? get id => _id;
  int? get userId => _userId;
  PostType? get type => _type;
  String? get content => _content;
  double? get lat => _lat;
  double? get lng => _lng;
  String? get address => _address;
  String? get placeId => _placeId;
  String? get placeType => _placeType;
  int? get status => _status;
  String? get privacy => _privacy;
  List<String>? get media => _media;
  int? get views => _views;
  DateTime? get createdAt => _createdAt;
  DateTime? get updatedAt => _updatedAt;
  int? get likesCount => _likesCount;
  int? get dislikedCount => _dislikesCount;
  int? get commentsCount => _commentsCount;
  int? get spotsCount => _spotsCount;
  int? get totalInteractionsCount => _totalInteractionsCount;
  User? get user => _user;
  Place? get place => _place;
  bool? get isLiked => _isLiked;
  bool? get isDisliked => _isDisliked;
  Spot? get spot => _spot;
  bool? get isSeen => _isSeen;
  int? get userCommentCount => _userCommentCount;

  void postLiked() {
    if (_isLiked ?? false) {
      _isLiked = false;
      _likesCount = (_likesCount ?? 0) - 1;
      _totalInteractionsCount = (_totalInteractionsCount ?? 0) - 1;
    } else {
      if (_isDisliked ?? false) {
        _totalInteractionsCount = (_totalInteractionsCount ?? 0) + 1;
        _isDisliked = false;
        _dislikesCount = (_dislikesCount ?? 0) - 1;
      }
      _isLiked = true;
      _likesCount = (_likesCount ?? 0) + 1;
      _totalInteractionsCount = (_totalInteractionsCount ?? 0) + 1;
    }
  }

  void postDisliked() {
    if (_isDisliked ?? false) {
      _isDisliked = false;
      _dislikesCount = (_dislikesCount ?? 0) - 1;
      _totalInteractionsCount = (_totalInteractionsCount ?? 0) + 1;
    } else {
      if (_isLiked ?? false) {
        _totalInteractionsCount = (_totalInteractionsCount ?? 0) - 1;
        _isLiked = false;
        _likesCount = (_likesCount ?? 0) - 1;
      }
      _isDisliked = true;
      _dislikesCount = (_dislikesCount ?? 0) + 1;
      _totalInteractionsCount = (_totalInteractionsCount ?? 0) - 1;
    }
  }

  void updatedCommentCount() {
    if (_commentsCount == null) {
      _commentsCount = 1;
    } else {
      _commentsCount = _commentsCount! + 1;
    }
    if (_userCommentCount == null) {
      _userCommentCount = 1;
    } else {
      _userCommentCount = _userCommentCount! + 1;
    }
  }

  void updateSpotStatus(Spot? _spot) {
    if (_spot != null) {
      this._spot = _spot;
      _spotsCount = (_spotsCount ?? 0) + 1;
    } else {
      this._spot = null;
      _spotsCount = (_spotsCount ?? 1) - 1;
    }
  }

  Post(
      {int? id,
      int? userId,
      PostType? type,
      String? content,
      double? lat,
      double? lng,
      String? address,
      String? placeId,
      String? placeType,
      int? status,
      String? privacy,
      List<String>? media,
      int? views,
      DateTime? createdAt,
      DateTime? updatedAt,
      int? likesCount,
      int? dislikedCount,
      int? commentsCount,
      int? spotsCount,
      int? totalInteractionsCount,
      User? user,
      Place? place,
      bool? isLiked,
      bool? isDisliked,
      Spot? spot,
      bool? isSeen,
      int? userCommentCount}) {
    _id = id;
    _userId = userId;
    _type = type;
    _content = content;
    _lat = lat;
    _lng = lng;
    _address = address;
    _placeId = placeId;
    _placeType = placeType;
    _status = status;
    _privacy = privacy;
    _media = media;
    _views = views;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _likesCount = likesCount;
    _dislikesCount = dislikedCount;
    _commentsCount = commentsCount;
    _spotsCount = spotsCount;
    _totalInteractionsCount = totalInteractionsCount;
    _user = user;
    _place = place;
    _isLiked = isLiked;
    _isDisliked = isDisliked;
    _spot = spot;
    _isSeen = isSeen;
    _userCommentCount = userCommentCount;
  }

  Post.fromJson(
    dynamic json,
  ) {
    if (json != null) {
      _id = json["id"];
      _userId = json["user_id"];
      _type = PostType.values
          .firstWhere((e) => e.toString() == 'PostType.${json["type"]}');
      _content = json["content"];
      _lat = json["lat"] as double;
      _lng = json["lng"] as double;
      _address = json["address"];
      _placeId = json["place_id"];
      _placeType = json["place_type"];
      _status = json["status"];
      _privacy = json["privacy"];
      if (json["media"] != null) {
        _media = [];
        json["media"].forEach((value) {
          _media!.add(value);
        });
      }
      _views = json["views"];
      _createdAt = json["created_at"] != null
          ? DateTime.parse(json["created_at"])
          : null;
      _updatedAt = json["updated_at"] != null
          ? DateTime.parse(json["updated_at"])
          : null;
      _likesCount = json["likes_count"];
      _dislikesCount = json['dislikes_count'];
      _commentsCount = json["comments_count"];
      _spotsCount = json['spots_count'];
      _totalInteractionsCount = json['total_count'];
      _user = json["user"] != null ? User.fromJson(json["user"]) : null;
      _place =
          json["place_type"] != null ? Place.fromJson(json["place"]) : null;
      _isLiked = !((json['is_liked'] ?? false) == false);
      _isDisliked = !((json['is_disliked'] ?? false) == false);
      _spot = json['spot'] != null ? Spot.fromJson(json['spot']) : null;
      _isSeen = json['seen_count'] == 1;
      _userCommentCount = json['user_comment_count'];
    }
  }
}
