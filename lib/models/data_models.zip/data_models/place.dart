// ignore_for_file: invalid_assignment
// ignore_for_file:argument_type_not_assignable
import 'package:spott/models/data_models/post.dart';

import 'follow.dart';

class Place {
  String? _id;
  dynamic _type;
  String? _name;
  dynamic _details;
  double? _lat;
  double? _lng;
  String? _fullAddress;
  int? _distance;
  String? _country;
  String? _city;
  dynamic _postalCode;
  String? _streetAddress;
  dynamic _building;
  dynamic _readyDate;
  int? _isReturn;
  dynamic _refId;
  dynamic _refType;
  String? _mainPicture;
  String? _coverPicture;
  int? _userId;
  String? _categoryId;
  dynamic _hashtags;
  List<String>? _images;
  String? _updatedAt;
  String? _createdAt;
  double? _averageRating;
  int? _followCount;
  int? _spotCount;
  List<Ratings>? _ratings;
  List<Post>? _stories;
  List<Post>? _posts;
  List<Follow>? _followers;

  String? get id => _id;
  dynamic get type => _type;
  String? get name => _name;
  dynamic get details => _details;
  double? get lat => _lat;
  double? get lng => _lng;
  String? get fullAddress => _fullAddress;
  int? get distance => _distance;
  String? get country => _country;
  String? get city => _city;
  dynamic get postalCode => _postalCode;
  String? get streetAddress => _streetAddress;
  dynamic get building => _building;
  dynamic get readyDate => _readyDate;
  int? get isReturn => _isReturn;
  dynamic get refId => _refId;
  dynamic get refType => _refType;
  String? get mainPicture => _mainPicture;
  String? get coverPicture => _coverPicture;
  int? get userId => _userId;
  String? get categoryId => _categoryId;
  dynamic get hashtags => _hashtags;
  List<String>? get images => _images;
  String? get updated => _updatedAt;
  String? get createdAT => _createdAt;
  double? get averageRating => _averageRating;
  int? get followCount => _followCount;
  int? get spotCount => _spotCount;
  List<Ratings>? get ratings => _ratings;
  List<Post>? get stories => _stories;
  List<Post>? get posts => _posts;
  List<Follow>? get followers => _followers;

  Place(
      {String? id,
      dynamic type,
      String? name,
      dynamic details,
      double? lat,
      double? lng,
      String? fullAddress,
      int? distance,
      String? country,
      String? city,
      dynamic postalCode,
      String? streetAddress,
      dynamic building,
      dynamic readyDate,
      int? isReturn,
      dynamic refId,
      dynamic refType,
      String? mainPicture,
      String? coverPicture,
      int? userId,
      String? categoryId,
      dynamic hashtags,
      List<String>? images,
      String? updatedAt,
      String? createdAt,
      double? averageRating,
      int? followCount,
      int? spotCount,
      List<Ratings>? ratings,
      List<Post>? stories,
      List<Post>? posts,
      List<Follow>? followers}) {
    _id = id;
    _type = type;
    _name = name;
    _details = details;
    _lat = lat;
    _lng = lng;
    _fullAddress = fullAddress;
    _distance = distance;
    _country = country;
    _city = city;
    _postalCode = postalCode;
    _streetAddress = streetAddress;
    _building = building;
    _readyDate = readyDate;
    _isReturn = isReturn;
    _refId = refId;
    _refType = refType;
    _mainPicture = mainPicture;
    _coverPicture = coverPicture;
    _userId = userId;
    _categoryId = categoryId;
    _hashtags = hashtags;
    _images = images;
    _updatedAt = updatedAt;
    _createdAt = createdAt;
    _averageRating = averageRating;
    _followCount = followCount;
    _spotCount = spotCount;
    _ratings = ratings;
    _stories = stories;
    _posts = posts;
    _followers = followers;
  }

  Place.fromJson(dynamic json) {
    if (json != null) {
      _id = json["id"]?.toString();
      _type = json["type"];
      _name = json["name"];
      _details = json["details"];
      _lat = ((json as Map).containsKey('lat'))
          ? ((json["lat"] is String)
              ? double.parse(json['lat'])
              : json["lat"]?.toDouble())
          : null;
      _lng = (json.containsKey('lng'))
          ? ((json["lng"] is String)
              ? double.parse(json['lng'])
              : json["lat"]?.toDouble())
          : null;
      _fullAddress = json["fullAddress"];
      _distance = (json["distance"] is int)
          ? json["distance"]
          : json["distance"] != null
              ? int.tryParse(json["distance"].toString())
              : null;
      _country = json["country"];
      _city = json["city"];
      _postalCode = json["postalCode"];
      _streetAddress = json["streetAddress"];
      _building = json["building"];
      _readyDate = json["readyDate"];
      _isReturn = json["isReturn"];
      _refId = json["ref_id"];
      _refType = json["ref_type"];
      _mainPicture = json["main_picture"];
      _coverPicture = json["cover_picture"];
      _userId = json["user_id"];
      _categoryId = json["category_id"]?.toString();
      _hashtags = json["hashtags"];
      if (json["images"] != null) {
        _images = [];
        json["images"].forEach((value) {
          _images!.add(value);
        });
      }
      _updatedAt = json['updated_at'];
      _createdAt = json['created_at'];
      _averageRating = json["average-rating"] != null
          ? double.parse(json["average-rating"].toString())
          : null;
      _followCount = json["follow-count"];
      _spotCount = json["spot-count"];
      if (json["ratings"] != null) {
        _ratings = [];
        json["ratings"].forEach((v) {
          _ratings?.add(Ratings.fromJson(v));
        });
      }
      if (json["stories"] != null) {
        _stories = [];
        json["stories"].forEach((v) {
          _stories?.add(Post.fromJson(v));
        });
      }
      if (json["posts"] != null) {
        _posts = [];
        json["posts"].forEach((v) {
          _posts?.add(Post.fromJson(v));
        });
      }
      if (json["followers"] != null) {
        _followers = [];
        json["followers"].forEach((v) {
          _followers?.add(Follow.fromJson(v));
        });
      }
    }
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map["id"] = _id;
    map["type"] = _type;
    map["name"] = _name;
    map["details"] = _details;
    map["lat"] = _lat;
    map['lng'] = _lng;
    map["fullAddress"] = _fullAddress;
    map["distance"] = _distance;
    map["country"] = _country;
    map["city"] = _city;
    map["postalCode"] = _postalCode;
    map["streetAddress"] = _streetAddress;
    map["building"] = _building;
    map["readyDate"] = _readyDate;
    map["isReturn"] = _isReturn;
    map["ref_id"] = _refId;
    map["ref_type"] = _refType;
    map["main_picture"] = _mainPicture;
    map["cover_picture"] = _coverPicture;
    map["user_id"] = _userId;
    map["category_id"] = _categoryId;
    map["hashtags"] = _hashtags;
    map['updated_at'] = _updatedAt;
    map["images"] = _images;
    map['created_at'] = _createdAt;
    map["average-rating"] = _averageRating;
    map["follow-count"] = _followCount;
    map["spot-count"] = _spotCount;
    map["ratings"] = _ratings;
    map["followers"] = _followers;
    return map;
  }
}

class Ratings {
  int? _id;
  int? _userId;
  int? _placeId;
  double? _rating;
  String? _comment;
  String? _createdAt;
  String? _updatedAt;

  int? get id => _id;
  int? get userId => _userId;
  int? get placeId => _placeId;
  double? get rating => _rating;
  String? get comment => _comment;
  String? get createdAt => _createdAt;
  String? get updatedAt => _updatedAt;

  Ratings(
      {int? id,
      int? userId,
      int? placeId,
      double? rating,
      String? comment,
      String? createdAt,
      String? updatedAt}) {
    _id = id;
    _userId = userId;
    _placeId = placeId;
    _rating = rating;
    _comment = comment;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
  }

  Ratings.fromJson(dynamic json) {
    _id = json["id"];
    _userId = json["user_id"];
    _placeId = json["place_id"];
    _rating = json["rating"];
    _comment = json["comment"];
    _createdAt = json["created_at"];
    _updatedAt = json["updated_at"];
  }
}
